package com.example.elvishtranslator;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import androidx.annotation.NonNull;
import java.util.ArrayList;


public class WordListAdapter extends ArrayAdapter<Word> {
    
    public WordListAdapter(@NonNull Context context, int resource, ArrayList<Word> words) {
        super(context, resource, words);

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null){
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.customview, parent, false);
        }

        Word words = getItem(position);

        TextView traducir = (TextView) convertView.findViewById(R.id.Numeros);
        traducir.setText(words.getTraducir());

        TextView traduccion = (TextView) convertView.findViewById(R.id.NumerosElf);
        traduccion.setText(words.getTraduccion());

        return convertView;
    }
}
