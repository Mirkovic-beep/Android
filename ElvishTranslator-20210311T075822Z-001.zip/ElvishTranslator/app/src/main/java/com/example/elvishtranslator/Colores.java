package com.example.elvishtranslator;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.widget.ListView;

import java.util.ArrayList;

public class Colores extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_colores);
        ListView list = findViewById(R.id.listaColores);

        Word palabra1 = new Word("Rojo", "Caran");
        Word palabra2 = new Word("Carmin", "Carnin");
        Word palabra3 = new Word("Azul", "Elu");
        Word palabra4 = new Word("Amarillo", "Malen");
        Word palabra5 = new Word("Verde", "Calen");
        Word palabra6 = new Word("Negro", "Morn");
        Word palabra7 = new Word("Marron", "Rhosg");
        Word palabra8 = new Word("Blanco", "Faen");
        Word palabra9 = new Word("Gris", "Mith");
        Word palabra10 = new Word("Naranja", "Cull");

        ArrayList<Word> words = new ArrayList<>();
        words.add(palabra1);
        words.add(palabra2);
        words.add(palabra3);
        words.add(palabra4);
        words.add(palabra5);
        words.add(palabra6);
        words.add(palabra7);
        words.add(palabra8);
        words.add(palabra9);
        words.add(palabra10);

        WordListAdapter adapter = new WordListAdapter(this,R.layout.customview,words);
        list.setAdapter(adapter);
    }
}