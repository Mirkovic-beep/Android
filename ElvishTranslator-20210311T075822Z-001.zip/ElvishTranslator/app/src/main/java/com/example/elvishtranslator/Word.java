package com.example.elvishtranslator;

public class Word {
    String traducir;
    String traduccion;

    public Word(String traducir, String traduccion) {
        this.traducir = traducir;
        this.traduccion=traduccion;
    }

    public String getTraducir() {
        return traducir;
    }

    public void setTraducir(String traducir) {
        this.traducir = traducir;
    }

    public String getTraduccion() {
        return traduccion;
    }

    public void setTraduccion(String traduccion) {
        this.traduccion = traduccion;
    }


    @Override
    public String toString() {
        return "Word{" +
                "traducir='" + traducir + '\'' +
                ", traduccion='" + traduccion + '\'' +
                '}';
    }
}
