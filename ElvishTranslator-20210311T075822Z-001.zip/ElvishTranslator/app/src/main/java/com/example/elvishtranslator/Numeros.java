package com.example.elvishtranslator;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.widget.ListView;

import java.util.ArrayList;

public class Numeros extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_numeros);
        ListView list = findViewById(R.id.listaNumeros);

        Word palabra1 = new Word("Uno", "mîn");
        Word palabra2 = new Word("Dos", "tâd");
        Word palabra3 = new Word("Tres", "nêl");
        Word palabra4 = new Word("Cuatro", "canad");
        Word palabra5 = new Word("Cinco", "leben");
        Word palabra6 = new Word("Seis", "eneg");
        Word palabra7 = new Word("Siete", "odog");
        Word palabra8 = new Word("Ocho", "tolodh");
        Word palabra9 = new Word("Nueve", "neder");
        Word palabra10 = new Word("Diez", "pae");

        ArrayList<Word> words = new ArrayList<>();
        words.add(palabra1);
        words.add(palabra2);
        words.add(palabra3);
        words.add(palabra4);
        words.add(palabra5);
        words.add(palabra6);
        words.add(palabra7);
        words.add(palabra8);
        words.add(palabra9);
        words.add(palabra10);

        WordListAdapter adapter = new WordListAdapter(this,R.layout.customview,words);
        list.setAdapter(adapter);

    }
}