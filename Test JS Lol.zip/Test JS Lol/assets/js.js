var botones= new Array();
var preguntas= new Array(4);
var contador = 0;
var div = document.getElementById("mostrar");

function validar(nPregunta,nRespuesta){

var boton = document.get
switch (nPregunta){

	case 1:
	for (var i = 1; i <= preguntas.length; i++) {

		if( nRespuesta == i){
			preguntas[0] = i;
		    desactivarBotones(nPregunta,nRespuesta);
		    contador++;
		   	revisarPregunta();
		}
	}
	break;

	case 2:

	for (var i = 1; i <= preguntas.length; i++) {

		if( nRespuesta == i){
			preguntas[1] = i;
		    desactivarBotones(nPregunta,nRespuesta);
		    contador++;
		    revisarPregunta();
		}
	}
	break;

	case 3:

	for (var i = 1; i <= preguntas.length; i++) {

		if( nRespuesta == i){
			preguntas[2] = i;
		    desactivarBotones(nPregunta,nRespuesta);
		    contador++;
		    revisarPregunta();
		}
	}
	break;

	case 4:

	for (var i = 1; i <= preguntas.length; i++) {

		if( nRespuesta == i){
			preguntas[3] = i;
			desactivarBotones(nPregunta,nRespuesta);
			contador++;
		    revisarPregunta();
		}
	}
	break;

	case 5:

	for (var i = 1; i <= preguntas.length; i++) {

		if( nRespuesta == i){
			preguntas[4] = i;
			desactivarBotones(nPregunta,nRespuesta);
			contador++;
		    revisarPregunta();
		}
	}
	break;
	}	
 }

function desactivarBotones(numero,nRespuesta){
	botones = document.getElementsByClassName("pregunta"+numero);

	console.log(nRespuesta);
		for (i=1;i<=botones.length;i++){
			if(i!=nRespuesta){
				botones[i-1].disabled=true;
			}else{
				botones[i-1].style.backgroundColor = '#337ab7';
			}
		}
}

function revisarPregunta(){

if(contador == 5){

	if(preguntas[0] == 1 && preguntas[1] == 1 && preguntas[2] == 1 && preguntas[3] == 1){
		mostrarResultados(1);
   	 	}

   	if(preguntas[0] == 2 && preguntas[1] == 2 && preguntas[2] == 2 && preguntas[3] == 2){
		mostrarResultados(2);
   	 	}

	if(preguntas[0] == 3 && preguntas[1] == 3 && preguntas[2] == 3 && preguntas[3] == 3){
		mostrarResultados(3);
   	 	}

	}

 }


function mostrarResultados(resultado){

	switch (resultado){
		case 1:
		div.innerHTML+='<h1>Eres teemo hijo de puta</h1>';
		div.innerHTML+='<img src="assets/images/teemo.jpg"/>';
		div.innerHTML+='<p>Eres un guarro</>';
		break;

		case 2:
		div.innerHTML+='<h1>Eres malzahar trozo de mierda</h1>';
		div.innerHTML+='<img src="assets/images/malza.jpg"/>';
		div.innerHTML+='<p>Eres un guarro</>';
		break;



		case 3:
		div.innerHTML+='<h1>Eres nasus autista</h1>';
		div.innerHTML+='<img src="assets/images/nasus.jpg"/>';
		div.innerHTML+='<p>Eres un guarro</>';
		break;

	}


}