package com.example.elvishtranslator;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.widget.ListView;

import java.util.ArrayList;

public class Frases extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_frases);
        ListView list = findViewById(R.id.listaFrases);

        Word palabra1 = new Word("Buena suerte / Adiós", "Galu");
        Word palabra2 = new Word("Ten alegría y risas", "Savo ‘lass a lalaith");
        Word palabra3 = new Word("Hasta mañana", "Abarad");
        Word palabra4 = new Word("¡Ten cuidado!", "No dirweg!");
        Word palabra5 = new Word("¡Mira!", "Alae!");
        Word palabra6 = new Word("Ven junto al fuego", "Tolo na naur");
        Word palabra7 = new Word("Aquí eres bienvenido", "Gi nathlam hí (informal) / Le nathlam hí (formal)");
        Word palabra8 = new Word("Estoy aquí para salvarte", "Udulen an edraith angin (informal) / Udulen an edraith anlen (formal)");
        Word palabra9 = new Word("Él/Ella está herido/a", "Aphado nin");
        Word palabra10 = new Word("Por favor", "An ngell nîn");

        ArrayList<Word> words = new ArrayList<>();
        words.add(palabra1);
        words.add(palabra2);
        words.add(palabra3);
        words.add(palabra4);
        words.add(palabra5);
        words.add(palabra6);
        words.add(palabra7);
        words.add(palabra8);
        words.add(palabra9);
        words.add(palabra10);

        WordListAdapter adapter = new WordListAdapter(this,R.layout.customview,words);
        list.setAdapter(adapter);
    }
}