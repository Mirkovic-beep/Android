package com.example.elvishtranslator;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.widget.ListView;

import java.util.ArrayList;

public class Familia extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_familia);
        ListView list = findViewById(R.id.listaFamilia);

        Word palabra1 = new Word("Madre", "Naneth");
        Word palabra2 = new Word("Padre", "Adanadar");
        Word palabra3 = new Word("Hijo", "Ionn");
        Word palabra4 = new Word("Hija", "Sell");
        Word palabra5 = new Word("Hermano", "Muindor");
        Word palabra6 = new Word("Hermana", "Muinthel");

        ArrayList<Word> words = new ArrayList<>();
        words.add(palabra1);
        words.add(palabra2);
        words.add(palabra3);
        words.add(palabra4);
        words.add(palabra5);
        words.add(palabra6);

        WordListAdapter adapter = new WordListAdapter(this,R.layout.customview,words);
        list.setAdapter(adapter);
    }
}