package com.example.elvishtranslator;

public class Word {
    String traducir;
    String traduccion;
    int imageid;



    public Word(String traducir, String traduccion,int imageid) {
        this.traducir = traducir;
        this.traduccion=traduccion;
        this.imageid=imageid;
    }

    public String getTraducir() {
        return traducir;
    }
    public String getTraduccion() {
        return traduccion;
    }
    public int getImageid(){return imageid; }

}
