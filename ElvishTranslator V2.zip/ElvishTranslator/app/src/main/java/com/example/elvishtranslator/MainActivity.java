package com.example.elvishtranslator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    TextView Numeros;
    TextView Familia;
    TextView Colores;
    TextView Frases;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Numeros = (TextView) findViewById(R.id.Numeros);
        Numeros.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                Intent numeros = new Intent(view.getContext(),Numeros.class);
                startActivity(numeros);
            }
        });

        Familia = (TextView) findViewById(R.id.Familia);
        Familia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Familia = new Intent(view.getContext(),Familia.class);
                startActivity(Familia);
            }
        });

        Colores = (TextView) findViewById(R.id.Colores);
        Colores.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Colores = new Intent(view.getContext(),Colores.class);
                startActivity(Colores);
            }
        });

        Frases = (TextView) findViewById(R.id.Frases);
        Frases.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Frases = new Intent(view.getContext(),Frases.class);
                startActivity(Frases);
            }
        });
        

    }
}